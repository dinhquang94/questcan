﻿$(document).ready(function () {
    $('#developers').pageMe({
        pagerSelector: '#developer_page',
        showPrevNext: true,
        hidePageNumbers: false, perPage: 11
    });
});